//Name: <your name here>
//Date: <date finished>
//Program: CSC1060Mod8Single_yourlastname

/*
 * CSC 1060 Module 9 Single: The Locker Problem Simulation
 * ------------------------------------------------------
 * IMPORTANT NOTE FOR STUDENTS:
 * This program intentionally uses a single one-dimensional boolean array (boolean[])
 * because that is exactly what the project requires.
 *
 * The project description says:
 * - 200 lockers (1..200), all start CLOSED
 * - 200 students (1..200)
 * - Student N toggles every Nth locker
 * - Toggling means: closed -> open, open -> closed
 * - At the end, display ONLY the open lockers
 * - The open locker numbers must be separated by exactly TWO spaces
 *
 * ALSO IMPORTANT:
 * The user request in this chat said "do NOT use arrays", but the actual assignment
 * document you linked explicitly requires a boolean[] array of size 200.
 * Since this file is meant to be a correct sample solution for the assignment,
 * it uses the required boolean[] array.
 *
 * If you truly need a "no arrays" version for earlier chapters, tell me and I can
 * provide a concept-demo that prints the perfect squares (1, 4, 9, ...) without
 * simulating all toggles—but that would NOT meet the project requirements.
 */

