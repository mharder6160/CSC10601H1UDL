//Name: <your name here>
//Date: <date finished>
//Program: CSC1060Mod6PP_yourlastname.java

import java.util.Random;
import java.util.Scanner;

/*
 * CSC 1060 - Module 6 Programming Project (Sample)
 * Project: Extended Card Game Simulation
 *
 * RESTRICTIONS (per request):
 *   - Use only ONE method total: main()
 *       (So: no helper methods.)
 *   - DO NOT use arrays.
 *   - Use only topics covered:
 *       primitive data types, basic Strings,
 *       conditional statements, loops,
 *       and simple input/output.
 *
 * WHAT THIS PROGRAM DEMONSTRATES:
 *   - A loop that plays repeated rounds of a card draw game
 *   - Random generation of two UNIQUE cards each round
 *   - Ace is highest ranking card
 *   - Counters to track Player 1 wins, Player 2 wins, and ties
 *   - Input validation for "yes" or "no" (case-insensitive)
 *
 * NOTE:
 *   - This does not simulate a full deck being depleted over time.
 *     It only guarantees that the two cards in the SAME round are unique,
 *     which matches the assignment wording ("For each round... generate two unique cards").
 */
public class CSC1060Mod6PP_yourlastname {

    public static void main(String[] args) {

        // Create objects for input and random number generation


        // ------------------------------------------------------------
        // Counters for the final summary
        // ------------------------------------------------------------


        // This controls our main game loop

        // ------------------------------------------------------------
        // MAIN GAME LOOP: repeats as long as user keeps saying "yes"
        // ------------------------------------------------------------

            // ========================================================
            // PART A: Generate Player 1 card
            // ========================================================

            /*
             * We represent rank using an int value:
             *   2..10 are numeric ranks
             *   11 = Jack
             *   12 = Queen
             *   13 = King
             *   14 = Ace  (highest)
             */

            /*
             * We represent suit using an int value:
             *   1 = Hearts
             *   2 = Diamonds
             *   3 = Clubs
             *   4 = Spades
             */

            // Convert Player 1 rank value to rank name (NO ARRAYS, so use if/else)

            // Convert Player 1 suit value to suit name

            // ========================================================
            // PART B: Generate Player 2 card (must be unique vs Player 1)
            // ========================================================


            /*
             * Uniqueness rule:
             *   Player 2 cannot have the SAME rank AND SAME suit as Player 1.
             * If that happens, keep generating Player 2's card again.
             */

            // Convert Player 2 rank value to rank name (NO ARRAYS, so use if/else)

            // Convert Player 2 suit value to suit name

            // ========================================================
            // PART C: Print the round results (required output)
            // ========================================================

            // ========================================================
            // PART D: Determine the winner based on rank values only
            // ========================================================

            // ========================================================
            // PART E: Ask user to play another round (input validation)
            // ========================================================

            /*
             * The project requires the program to ask:
             *   "Would you like to play another round? (yes or no)"
             *
             * The loop continues as long as the user enters "yes"
             * The loop stops when the user enters "no"
             * Anything else must show an "Invalid input!" message and re-prompt
             */

        // ------------------------------------------------------------
        // FINAL SUMMARY: print when user chooses to stop
        // ------------------------------------------------------------

        // Close scanner


    }
}