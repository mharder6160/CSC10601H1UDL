//Name: <NAME>
//Date: <DATE>
//Program: CSC1060 Module 3 Programming Project
//Program Description: This program calculates the gravitational acceleration for Earth, the Moon, and Mars based on user-input diameters.
//Inputs: The diameters of Earth, Moon, and Mars.
//Outputs: The calculated gravitational acceleration for each celestial body and an ASCII art of a spaceship.

import java.util.Scanner;

public class CSC1060Mod3PP_yourlastname {

    public static void main(String[] args) {

        // --- SECTION 1: CONSTANTS AND VARIABLES ---
        // Define constants for the gravitational constant and the masses of the celestial bodies.
      

        // Declare variables for diameters and radii.

        
        // Declare variables to store the calculated gravity.


        // Create a Scanner object for user input.


        // --- SECTION 2: USER INPUT ---

        // Prompt the user for the diameter of Earth.


        // Prompt the user for the diameter of the Moon.

        // Prompt the user for the diameter of Mars.

        // Close the scanner to prevent resource leaks.

        // --- SECTION 3: CALCULATIONS ---
        // Calculate the radius for each celestial body (Radius = Diameter / 2).

        // Calculate gravity using the formula: g = G * (M / R^2).

        // --- SECTION 4: DISPLAY RESULTS ---
        
        // --- SECTION 5: ASCII ART ---

    }
}