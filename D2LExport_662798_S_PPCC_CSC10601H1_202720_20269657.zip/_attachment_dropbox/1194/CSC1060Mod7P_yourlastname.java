//Name: <your name here>
//Date: <date finished>
//Program: CSC1060Mod7P_yourlastname

/*
    CSC 1060 Module 7 Programming Project (Sample Solution)
    "Secure Password Validation Program"

    IMPORTANT NOTES FOR STUDENTS:
    1) This is a SAMPLE PROGRAM written as a learning example.
       Your instructor may want different method names, formatting, or output.
    2) This program is intentionally limited to topics typically covered early:
       - primitive data types
       - basic Strings
       - conditional statements (if / else)
       - loops (while / for)
       - methods
       - NO ARRAYS (not used here)
    3) This program demonstrates "modularity":
       main() calls helper methods to validate each rule.
    4) We print ALL rules the password failed, not just the first one.

    Project rules (from the assignment sheet):
    - Length: at least 10 characters
    - Character Set: only letters (A-Z, a-z) and digits (0-9). No special characters.
    - Digit Count: at least two digits
    - Case Mix: at least one lowercase letter and at least one uppercase letter
    - Program must keep prompting until password is valid
    - If invalid, print "Invalid Password:" followed by ALL failed rule messages
    - If valid, print "Valid Password!", break loop, and print the length
    - Must have at least two methods besides main (we have several)
    - Do not use global variables (we do not)
*/

import java.util.Scanner;

public class CSC1060Mod7P_yourlastname {

    public static void main(String[] args) {
        // Scanner reads keyboard input from the user.

        // We will keep asking until the user enters a valid password.

            // Prompt user for a password.

            // Determine whether the password is valid.
            // This method checks ALL rules and prints ALL failure messages.

            // If not valid, the helper method already printed why.
            // The loop repeats and asks again.

        // Good practice: close the scanner when finished.

    }

    /*
        isValidPasswordAndPrintFailures
        - Returns true if the password meets ALL requirements.
        - If the password is invalid, prints:
            "Invalid Password:"
            followed by one line for each failed rule.

        Why do it this way?
        - The project requires that we list all rules the password failed.
        - Doing "all checks" in one place helps keep main() clean.
    */
    public static boolean isValidPasswordAndPrintFailures(String password) {

        // We will keep track of whether we found any failures.
        // Start by assuming it is valid; if any rule fails, set valid to false.

        // Print failures in a consistent format:
        // Only print the header if at least one rule fails.
        // To do that, we can delay printing the header until we know there is a failure.

        // Rule 1: length at least 10

        // Rule 2: only letters and digits

        // Rule 3: at least two digits

        // Rule 4: at least one lowercase AND at least one uppercase

            // We can provide very specific feedback to help students/users.
            // For example, we can say which part is missing.

    }

    /*
        Helper: prints the required "Invalid Password:" header once.

        Parameter:
            printedHeader - whether we already printed the header

        Returns:
            true (meaning "header is now printed")
    */
    public static boolean printInvalidHeaderIfNeeded(boolean printedHeader) {
        if (!printedHeader) {
            System.out.println("Invalid Password:");
        }
        return true;
    }

    // -------------------------
    // Rule-checking methods
    // -------------------------

    /*
        Rule 1: Length must be at least 10 characters.
        Note: String.length() returns the number of characters in the String.
    */
    public static boolean meetsLengthRule(String password) {


    }

    /*
        Rule 2: Only letters and digits.
        Approach:
        - Look at each character in the password using charAt(i).
        - If ANY character is NOT a letter and NOT a digit, fail the rule.
        - If we finish the loop without finding a bad character, pass the rule.
    */
    public static boolean containsOnlyLettersAndDigits(String password) {

            // We use Character methods so we do not need arrays or complicated logic.
            // Character.isLetter checks A-Z and a-z (and other letters, too).
            // Character.isDigit checks 0-9 (and other digits, too).

    }

    /*
        Rule 3: Must contain at least two digits.
        Approach:
        - Count digits while looping through the String.
        - If digitCount >= 2, pass; otherwise fail.
    */
    public static boolean hasAtLeastTwoDigits(String password) {

                // Small efficiency improvement:
                // As soon as we know we have 2 digits, we can return true.

        }

        // If we finish the loop and did not reach 2 digits, fail.
        return false;
    }

    /*
        Rule 4: Must contain at least one lowercase letter AND at least one uppercase letter.
        We break this rule into two simpler checks to keep the logic readable.
    */
    public static boolean hasLowercaseAndUppercase(String password) {

    }

    /*
        Checks for at least one lowercase letter (a-z).
        Character.isLowerCase(ch) returns true for lowercase letters.
    */
    public static boolean hasAtLeastOneLowercaseLetter(String password) {

    }

    /*
        Checks for at least one uppercase letter (A-Z).
        Character.isUpperCase(ch) returns true for uppercase letters.
    */
    public static boolean hasAtLeastOneUppercaseLetter(String password) {

    }

}