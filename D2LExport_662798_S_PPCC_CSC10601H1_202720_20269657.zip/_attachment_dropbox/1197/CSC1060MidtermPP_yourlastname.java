//Name: <your name here>
//Date: <date finished>
//Program: CSC1060MidtermPP_yourlastname

import java.util.Scanner;

/*
 * CSC1060 Mid Term Programming Project - Sample Solution (Heavily Commented)
 * -----------------------------------------------------------------------------
 * This is a simplified version of the dice game "Craps" using ONLY topics
 * you said have been covered so far:
 *   - primitive data types (int, boolean)
 *   - basic Strings
 *   - conditionals (if/else)
 *   - loops (while / do-while)
 *   - methods (all in ONE .java file)
 *   - Math.random() for random dice rolls
 *
 * IMPORTANT CONSTRAINTS (per your request):
 *   - One .java file
 *   - All methods in this one file (one class/module)
 *   - NO arrays (not covered yet)
 *
 * PROJECT REQUIREMENTS (based on the assignment description):
 *   1) Ask player name (Scanner), use it throughout
 *   2) Allow multiple rounds (main game loop) until player quits
 *   3) Roll two dice using Math.random(), sum them, display dice
 *   4) Craps rules:
 *       - First roll:
 *           Lose immediately on 2, 3, 12
 *           Win immediately on 7, 11
 *           Otherwise: point is established (4,5,6,8,9,10)
 *       - Point phase:
 *           Keep rolling until:
 *             * roll point again => win
 *             * roll 7 => lose
 *   5) Special Win Condition:
 *       If point is even (4,6,8,10) AND player wins by rolling doubles
 *       that match the point (example: point=8 and roll 4 + 4), print
 *       "Special Win" and count it.
 *   6) Track statistics: totalWins, totalLosses, specialWins
 *   7) When quitting, print final statistics
 */


