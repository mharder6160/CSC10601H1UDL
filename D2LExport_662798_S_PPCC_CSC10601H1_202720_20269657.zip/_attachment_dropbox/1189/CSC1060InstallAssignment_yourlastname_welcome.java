public class CSC1060InstallAssignment_yourlastname_welcome {
	public static void main(String[] args) {
		// Display message Welcome to Java! on the console
		System.out.println("Welcome to Java!");
		// Comment Display message My name is xxx and I was born in yyy! on the console
		// Comment System.out.println("My name is xxx and I was born in yyy!");
                
	}
}