//Name: <NAME>
//Date: <DATE>
//CSC1060 Module 12 Programming Project
//Program Description: <Enter Program Description>
//Inputs: <Enter Inputs >
//Outputs: <Enter Outputs>


//Example code snippet to illustrate file not found handling for hangman.txt
//Replace 'yourlastname' with your actual last name in the class name

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CSC1060Mod11PP_yourlastname {
    public static void main(String[] args) {
        // Try to open hangman.txt file
        File file = new File("hangman.txt");
        Scanner input = null;
        
        try {
            input = new Scanner(file);
            // Insert rest of game logic here if file opens successfully
            System.out.println("hangman.txt file found. Proceed with game setup.");
        } catch (FileNotFoundException e) {
            // If the file is not found, display error message and exit
            System.out.println("Error: hangman.txt file NOT found.");
            System.exit(1); // Exit the program after error
        }

        // (Other game code would go here, using 'input' to read words, etc.)

        // Make sure to close the scanner if used
        if (input != null) {
            input.close();
        }
    }
}