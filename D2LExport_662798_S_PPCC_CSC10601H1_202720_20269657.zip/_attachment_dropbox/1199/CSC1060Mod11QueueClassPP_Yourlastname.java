//Name: < Your Name >
//Date: < Current Date >
//Program: CSC1060Mod11QueueClassPP_Yourlastname.java

/**
 * CSC1060Mod11QueueClassPP_Yourlastname.java
 * -----------------------------------------------------------------------------
 * This file contains:
 *   1) A custom Queue class that stores int values using an array.
 *   2) A main method test program that demonstrates:
 *        - Instantiation
 *        - Enqueueing 25 numbers (10..250)
 *        - Calling isFull() BEFORE each enqueue and printing the result
 *        - Dequeueing all numbers and printing them
 *
 * IMPORTANT (course-level constraints):
 * - Uses only: primitive data types, arrays, basic Strings, conditionals, loops,
 *   methods, classes/objects.
 * - No use of ArrayList, LinkedList, built-in Queue, etc.
 *
 * Notes for students:
 * - This Queue is implemented with "shifting" on dequeue().
 * - This keeps the "front" always at index 0.
 * - Shifting is simple to understand, but not the most efficient for large queues.
 */
