//Name: <your Name>
//Date: <current date>
//Program: CSC1060Mod10AccountClassPP_yourlastname

import java.util.Date;
import java.text.SimpleDateFormat;

/*
    CSC1060 Module 10 - Account Class Programming Project (Sample)
    File: CSC1060Mod10AccountClassPP_yourlastname.java

    IMPORTANT for students:
    - In Java, a class is usually stored in a file with the same name as the class.
      If your class name is CSC1060Mod10AccountClassPP_yourlastname,
      then the file should be CSC1060Mod10AccountClassPP_yourlastname.java.

    This class models a basic bank account and matches the project requirements:
      - private int id (default 1500)
      - private double balance (default 0.0)
      - private static double annualInterestRate (default 0.0, shared by all accounts)
      - private Date dateOpened (stores date account is created)
      - constructors: no-arg + (id, initialBalance)
      - getters/setters for id, balance, annualInterestRate
      - getter only for dateOpened
      - getMonthlyInterestRate(): annualInterestRate / 12
      - getMonthlyInterest(): balance * (monthlyInterestRate / 100)
      - withdraw(amount): subtracts from balance
      - deposit(amount): adds to balance
      - PrintAccount(): prints all details
*/
