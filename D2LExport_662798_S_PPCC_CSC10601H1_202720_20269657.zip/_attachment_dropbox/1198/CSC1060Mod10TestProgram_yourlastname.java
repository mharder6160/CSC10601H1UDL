//Name: <your Name>
//Date: <current date>
//Program: CSC1060Mod10TestProgram_yourlastname

/*
    CSC1060 Module 10 - Account Class Programming Project (Sample Test Program)
    File: CSC1060Mod10TestProgram_yourlastname.java

    This program tests the Account class exactly like the project scenario:

      1) Create an Account object with:
         id = 1234
         balance = 10000
         annualInterestRate = 2.5

      2) Withdraw 1500
      3) Deposit 3000
      4) Withdraw 750
      5) Call PrintAccount()

    Extra teaching pieces included:
      - arrays (store transactions)
      - loops (process transactions)
      - conditionals (decide deposit vs withdraw)
      - strings (labels for output)
*/
