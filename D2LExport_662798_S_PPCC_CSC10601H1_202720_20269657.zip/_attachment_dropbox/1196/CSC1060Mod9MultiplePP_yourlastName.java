//Name: <your name here>
//Date: <date finished>
//Program: CSC1060Mod9MultiplePP_yourlastName


import java.util.Scanner;

/*
    Connect Four (8x8) - Sample Program for Students
    ------------------------------------------------
    This file is intentionally written in an "early Java" style and is heavily commented.

    Topics used (matches an early-course toolset):
        - primitive types (int, char, boolean)
        - arrays (including 2D arrays)
        - basic Strings (printing, concatenation)
        - conditional statements (if / else)
        - loops (for, while, do-while)
        - methods (static methods)

    Project goals based on the assignment description (Module 9):
        - Build a simplified Connect Four game in Java
        - Use an 8x8 grid (8 rows, 8 columns)
        - Two players take turns dropping a piece into a column
        - Pieces fall to the lowest available row in that column ("gravity")
        - Win: 4 in a row (horizontal, vertical, diagonal)
        - Draw: board is full and nobody wins
        - Prompt columns 1..8 (user-friendly), but convert to 0..7 internally
        - Display a column header 1..8 underneath the board

    Notes for instructors / students:
        - This is console-based (text UI).
        - This code focuses on clarity, not being the shortest possible.
        - We avoid advanced Java features (classes beyond this one, ArrayList, exceptions as control-flow, etc.).
*/

