// Name: [Your Name]
// Date: [Date]
// Program Name: CSC1060Mod4PP_yourlastname.java
// Description: This program simulates one round of the card game War
// between two players, using numerical values for comparison and string literals
// for output. .
// Inputs: None
// Outputs: The cards drawn by each player and the winner of the round,
// with card names derived from conditional logic.

public class CSC1060Mod4PP_yourlastname {

    public static void main(String[] args) {

        // Generate a random number from 1 to 13 for Player 1's card rank
 
        // Generate a random number from 1 to 4 for Player 1's card suit
 
        // Generate a random number from 1 to 13 for Player 2's card rank
 
        // Generate a random number from 1 to 4 for Player 2's card suit
 
         // Print Player 1's card name using nested conditional logic and string literals
 
        // Determine and print the rank
 
        // Print the word "of" and determine and print the suit
 
        // Print Player 2's card name using nested conditional logic and string literals
 
        // Determine and print the rank
 
        // Print the word "of" and determine and print the suit
 
        // Determine the winner by comparing the rank numbers
        // Ace (1) is the highest
 
    }
}